from django.urls import path
from Mix_Match import views

urlpatterns = [
    path('',views.Mix_Match)
]
